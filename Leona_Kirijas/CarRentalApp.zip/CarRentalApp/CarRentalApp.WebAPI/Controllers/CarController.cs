﻿using CarRentalApp.Service.Interfaces;
using CarRentalApp.WebAPI.DTOs;
using Microsoft.AspNetCore.Mvc;
using AutoMapper;
using CarRentalApp.Domain.Entities;

namespace CarRentalApp.WebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CarController : ControllerBase
    {
        private readonly ICarService _carService;
        private readonly IMapper _mapper;

        public CarController(ICarService carService, IMapper mapper)
        {
            _carService = carService;
            _mapper = mapper;
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var cars = await _carService.GetAllAsync();
            var carsDto = _mapper.Map<IEnumerable<CarDto>>(cars);
            return Ok(carsDto);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var car = await _carService.GetByIdAsync(id);
            if (car == null)
            {
                return NotFound();
            }
            var carDto = _mapper.Map<CarDto>(car);
            return Ok(carDto);
        }

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] CarDto carDto)
        {
            var car = _mapper.Map<Car>(carDto);
            await _carService.AddAsync(car);
            return CreatedAtAction(nameof(GetById), new { id = car.Id }, carDto);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] CarDto carDto)
        {
            var car = await _carService.GetByIdAsync(id);
            if (car == null)
            {
                return NotFound();
            }
            _mapper.Map(carDto, car);
            await _carService.UpdateAsync(car);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var car = await _carService.GetByIdAsync(id);
            if (car == null)
            {
                return NotFound();
            }
            await _carService.DeleteAsync(id);
            return NoContent();
        }
    }
}
