﻿using AutoMapper;
using CarRentalApp.Domain.Entities;
using CarRentalApp.WebAPI.DTOs;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace CarRentalApp.WebAPI.Mappings
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            CreateMap<Client, ClientDto>().ReverseMap();
            CreateMap<Car, CarDto>().ReverseMap();
        }
    }
}