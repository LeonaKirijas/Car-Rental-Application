﻿using CarRentalApp.Domain.Entities;
using Microsoft.EntityFrameworkCore;

namespace CarRentalApp.Data
{
    public class DataContext : DbContext
    {
        public DataContext(DbContextOptions<DataContext> options) : base(options) { }

        public DbSet<Client> Clients { get; set; }
        public DbSet<Car> Cars { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Client>()
                .HasKey(c => c.Id);

            modelBuilder.Entity<Client>()
                .Property(c => c.FirstName)
                .IsRequired()
                .HasMaxLength(200);

            modelBuilder.Entity<Client>()
                .Property(c => c.LastName)
                .IsRequired()
                .HasMaxLength(400);

            modelBuilder.Entity<Client>()
                .Property(c => c.DOB)
                .IsRequired();

            modelBuilder.Entity<Client>()
                .Property(c => c.Address)
                .IsRequired()
                .HasMaxLength(500);

            modelBuilder.Entity<Client>()
                .Property(c => c.Nationality)
                .IsRequired();

            modelBuilder.Entity<Client>()
                .Property(c => c.RentalStartDate)
                .IsRequired();

            modelBuilder.Entity<Client>()
                .Property(c => c.RentalEndDate)
                .IsRequired();

            modelBuilder.Entity<Client>()
                .HasOne(c => c.Car)
                .WithMany(c => c.Clients)
                .HasForeignKey(c => c.CarId);

            modelBuilder.Entity<Car>()
                .HasKey(c => c.Id);

            modelBuilder.Entity<Car>()
                .Property(c => c.LicensePlate)
                .IsRequired();

            modelBuilder.Entity<Car>()
                .Property(c => c.Model)
                .IsRequired();

            modelBuilder.Entity<Car>()
                .Property(c => c.Manufacturer)
                .IsRequired();

            modelBuilder.Entity<Car>()
                .Property(c => c.Year)
                .IsRequired();
        }
    }
}