﻿namespace CarRentalApp.Data
{
    public class Class1
    {

    }
}
