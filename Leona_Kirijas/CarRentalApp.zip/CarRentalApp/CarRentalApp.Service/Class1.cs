﻿namespace CarRentalApp.Service
{
    public class Class1
    {

    }
}
