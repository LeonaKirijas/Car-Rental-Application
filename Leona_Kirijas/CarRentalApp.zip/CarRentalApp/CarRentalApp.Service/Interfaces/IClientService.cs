﻿using CarRentalApp.Domain.Entities;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CarRentalApp.Service.Interfaces
{
    public interface IClientService
    {
        Task<IEnumerable<Client>> GetAllAsync();
        Task<Client> GetByIdAsync(int id);
        Task AddAsync(Client client);
        Task UpdateAsync(Client client);
        Task DeleteAsync(int id);
    }
}
