﻿namespace CarRentalApp.Domain
{
    public class Class1
    {

    }
}
