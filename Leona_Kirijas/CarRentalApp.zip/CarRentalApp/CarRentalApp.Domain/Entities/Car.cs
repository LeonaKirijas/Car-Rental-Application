﻿namespace CarRentalApp.Domain.Entities
{
    public class Car
    {
        public int Id { get; set; }
        public string LicensePlate { get; set; }
        public string Model { get; set; }
        public string Manufacturer { get; set; }
        public int Year { get; set; }
        public ICollection<Client> Clients { get; set; }
    }
}
