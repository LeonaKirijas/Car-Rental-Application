﻿using CarRentalApp.Data.Interfaces;
using CarRentalApp.Domain.Entities;
using CarRentalApp.Service.Services;
using Moq;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Xunit;

namespace CarRentalApp.Tests.Services
{
    public class ClientServiceTests
    {
        private readonly Mock<IClientRepository> _mockClientRepository;
        private readonly ClientService _clientService;

        public ClientServiceTests()
        {
            _mockClientRepository = new Mock<IClientRepository>();
            _clientService = new ClientService(_mockClientRepository.Object);
        }

        [Fact]
        public async Task GetAllAsync_ShouldReturnAllClients()
        {
            var clients = new List<Client>
            {
                new Client { Id = 1, FirstName = "John", LastName = "Doe", CarId = 1 },
                new Client { Id = 2, FirstName = "Jane", LastName = "Doe", CarId = 2 }
            };
            _mockClientRepository.Setup(repo => repo.GetAllAsync()).ReturnsAsync(clients);

            var result = await _clientService.GetAllAsync();

            Assert.Equal(2, result.Count());
            Assert.Equal("John", result.First().FirstName);
        }

        [Fact]
        public async Task GetByIdAsync_ShouldReturnClient()
        {
            var client = new Client { Id = 1, FirstName = "John", LastName = "Doe", CarId = 1 };
            _mockClientRepository.Setup(repo => repo.GetByIdAsync(1)).ReturnsAsync(client);

            var result = await _clientService.GetByIdAsync(1);

            Assert.Equal("John", result.FirstName);
        }

        [Fact]
        public async Task AddAsync_ShouldAddClient()
        {
            var client = new Client { Id = 1, FirstName = "John", LastName = "Doe", CarId = 1 };
            await _clientService.AddAsync(client);

            _mockClientRepository.Verify(repo => repo.AddAsync(client), Times.Once);
        }

        [Fact]
        public async Task UpdateAsync_ShouldUpdateClient()
        {
            var client = new Client { Id = 1, FirstName = "John", LastName = "Doe", CarId = 1 };
            await _clientService.UpdateAsync(client);

            _mockClientRepository.Verify(repo => repo.UpdateAsync(client), Times.Once);
        }

        [Fact]
        public async Task DeleteAsync_ShouldDeleteClient()
        {
            await _clientService.DeleteAsync(1);

            _mockClientRepository.Verify(repo => repo.DeleteAsync(1), Times.Once);
        }
    }
}