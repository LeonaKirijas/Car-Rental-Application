﻿using CarRentalApp.Data.Interfaces;
using CarRentalApp.Domain.Entities;
using CarRentalApp.Service.Services;
using Moq;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Xunit;

namespace CarRentalApp.Tests.Services
{
    public class CarServiceTests
    {
        private readonly Mock<ICarRepository> _mockCarRepository;
        private readonly CarService _carService;

        public CarServiceTests()
        {
            _mockCarRepository = new Mock<ICarRepository>();
            _carService = new CarService(_mockCarRepository.Object);
        }

        [Fact]
        public async Task GetAllAsync_ShouldReturnAllCars()
        {
            var cars = new List<Car>
            {
                new Car { Id = 1, LicensePlate = "ABC123", Model = "Model S", Manufacturer = "Tesla", Year = 2020 },
                new Car { Id = 2, LicensePlate = "DEF456", Model = "Model 3", Manufacturer = "Tesla", Year = 2021 }
            };
            _mockCarRepository.Setup(repo => repo.GetAllAsync()).ReturnsAsync(cars);

            var result = await _carService.GetAllAsync();

            Assert.Equal(2, result.Count());
            Assert.Equal("Model S", result.First().Model);
        }

        [Fact]
        public async Task GetByIdAsync_ShouldReturnCar()
        {
            var car = new Car { Id = 1, LicensePlate = "ABC123", Model = "Model S", Manufacturer = "Tesla", Year = 2020 };
            _mockCarRepository.Setup(repo => repo.GetByIdAsync(1)).ReturnsAsync(car);

            var result = await _carService.GetByIdAsync(1);

            Assert.Equal("Model S", result.Model);
        }

        [Fact]
        public async Task AddAsync_ShouldAddCar()
        {
            var car = new Car { Id = 1, LicensePlate = "ABC123", Model = "Model S", Manufacturer = "Tesla", Year = 2020 };
            await _carService.AddAsync(car);

            _mockCarRepository.Verify(repo => repo.AddAsync(car), Times.Once);
        }

        [Fact]
        public async Task UpdateAsync_ShouldUpdateCar()
        {
            var car = new Car { Id = 1, LicensePlate = "ABC123", Model = "Model S", Manufacturer = "Tesla", Year = 2020 };
            await _carService.UpdateAsync(car);

            _mockCarRepository.Verify(repo => repo.UpdateAsync(car), Times.Once);
        }

        [Fact]
        public async Task DeleteAsync_ShouldDeleteCar()
        {
            await _carService.DeleteAsync(1);

            _mockCarRepository.Verify(repo => repo.DeleteAsync(1), Times.Once);
        }
    }
}
